import Foundation

struct VPNProfile {
    var displayName: String
    var server: String
    var remoteIdentifier: String
    var username: String
    var password: String
}
