import Foundation

enum MobileConfigBuilderError: LocalizedError {
    case missingRequiredField

    var errorDescription: String? {
        switch self {
        case .missingRequiredField:
            return "Sunucu, uzak kimlik, kullanıcı adı ve şifre alanları zorunludur."
        }
    }
}

struct MobileConfigBuilder {
    static func make(profile: VPNProfile) throws -> Data {
        let displayName = profile.displayName.trimmingCharacters(in: .whitespacesAndNewlines)
        let server = profile.server.trimmingCharacters(in: .whitespacesAndNewlines)
        let remoteIdentifier = profile.remoteIdentifier.trimmingCharacters(in: .whitespacesAndNewlines)
        let username = profile.username.trimmingCharacters(in: .whitespacesAndNewlines)
        let password = profile.password

        guard !server.isEmpty,
              !remoteIdentifier.isEmpty,
              !username.isEmpty,
              !password.isEmpty else {
            throw MobileConfigBuilderError.missingRequiredField
        }

        let profileUUID = UUID().uuidString.uppercased()
        let vpnUUID = UUID().uuidString.uppercased()
        let safeName = xml(displayName.isEmpty ? "Res VPN" : displayName)
        let safeServer = xml(server)
        let safeRemoteID = xml(remoteIdentifier)
        let safeUsername = xml(username)
        let safePassword = xml(password)

        let plist = """
        <?xml version="1.0" encoding="UTF-8"?>
        <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
        <plist version="1.0">
        <dict>
            <key>PayloadContent</key>
            <array>
                <dict>
                    <key>PayloadDescription</key>
                    <string>Res VPN IKEv2 bağlantısı</string>
                    <key>PayloadDisplayName</key>
                    <string>\(safeName)</string>
                    <key>PayloadIdentifier</key>
                    <string>com.resvpn.profile.vpn.\(vpnUUID)</string>
                    <key>PayloadType</key>
                    <string>com.apple.vpn.managed</string>
                    <key>PayloadUUID</key>
                    <string>\(vpnUUID)</string>
                    <key>PayloadVersion</key>
                    <integer>1</integer>

                    <key>UserDefinedName</key>
                    <string>\(safeName)</string>
                    <key>VPNType</key>
                    <string>IKEv2</string>

                    <key>IKEv2</key>
                    <dict>
                        <key>RemoteAddress</key>
                        <string>\(safeServer)</string>
                        <key>RemoteIdentifier</key>
                        <string>\(safeRemoteID)</string>

                        <key>AuthenticationMethod</key>
                        <string>None</string>
                        <key>ExtendedAuthEnabled</key>
                        <integer>1</integer>
                        <key>AuthName</key>
                        <string>\(safeUsername)</string>
                        <key>AuthPassword</key>
                        <string>\(safePassword)</string>

                        <key>DeadPeerDetectionRate</key>
                        <string>Medium</string>
                        <key>DisableMOBIKE</key>
                        <integer>0</integer>
                        <key>DisableRedirect</key>
                        <integer>0</integer>
                        <key>EnablePFS</key>
                        <integer>1</integer>
                    </dict>

                    <key>IPv4</key>
                    <dict>
                        <key>OverridePrimary</key>
                        <integer>1</integer>
                    </dict>

                    <key>Proxies</key>
                    <dict>
                        <key>HTTPEnable</key>
                        <integer>0</integer>
                        <key>HTTPSEnable</key>
                        <integer>0</integer>
                    </dict>
                </dict>
            </array>

            <key>PayloadDescription</key>
            <string>Res VPN tarafından oluşturulan kişisel IKEv2 profili.</string>
            <key>PayloadDisplayName</key>
            <string>\(safeName)</string>
            <key>PayloadIdentifier</key>
            <string>com.resvpn.profile.\(profileUUID)</string>
            <key>PayloadOrganization</key>
            <string>Res VPN</string>
            <key>PayloadRemovalDisallowed</key>
            <false/>
            <key>PayloadScope</key>
            <string>User</string>
            <key>PayloadType</key>
            <string>Configuration</string>
            <key>PayloadUUID</key>
            <string>\(profileUUID)</string>
            <key>PayloadVersion</key>
            <integer>1</integer>
        </dict>
        </plist>
        """

        return Data(plist.utf8)
    }

    private static func xml(_ value: String) -> String {
        value
            .replacingOccurrences(of: "&", with: "&amp;")
            .replacingOccurrences(of: "<", with: "&lt;")
            .replacingOccurrences(of: ">", with: "&gt;")
            .replacingOccurrences(of: "\"", with: "&quot;")
            .replacingOccurrences(of: "'", with: "&apos;")
    }
}
