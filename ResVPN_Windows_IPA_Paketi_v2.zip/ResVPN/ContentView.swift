import SwiftUI

struct ContentView: View {
    @AppStorage("vpnDisplayName") private var displayName = "Res VPN"
    @AppStorage("vpnServer") private var server = ""
    @AppStorage("vpnRemoteIdentifier") private var remoteIdentifier = ""
    @AppStorage("vpnUsername") private var username = ""

    @State private var password = ""
    @State private var exportURL: URL?
    @State private var showShareSheet = false
    @State private var errorMessage: String?
    @FocusState private var focusedField: Field?

    private enum Field {
        case displayName, server, remoteIdentifier, username, password
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 18) {
                    statusCard

                    VStack(alignment: .leading, spacing: 14) {
                        Text("IKEv2 PROFİLİ")
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(.secondary)

                        field("Profil adı", text: $displayName, field: .displayName)
                        field("Sunucu / alan adı", text: $server, field: .server,
                              keyboard: .URL, capitalization: .never)
                        field("Remote Identifier", text: $remoteIdentifier, field: .remoteIdentifier,
                              keyboard: .URL, capitalization: .never)
                        field("Kullanıcı adı", text: $username, field: .username,
                              capitalization: .never)

                        SecureField("Şifre", text: $password)
                            .textContentType(.password)
                            .focused($focusedField, equals: .password)
                            .padding(14)
                            .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 14))

                        Text("Şifre uygulamada kalıcı olarak saklanmaz. Profil dosyasına yazılır; profil dosyasını güvenli tut.")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                    .padding(18)
                    .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 22))

                    Button(action: createProfile) {
                        Label("VPN Profilini Oluştur", systemImage: "shield.lefthalf.filled")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 15)
                    }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)

                    VStack(alignment: .leading, spacing: 8) {
                        Label("Nasıl çalışır?", systemImage: "info.circle")
                            .font(.headline)

                        Text("Bu ücretsiz sürüm Apple'ın yerleşik IKEv2 VPN motoru için bir .mobileconfig profili üretir. Profili iPhone'a kurduktan sonra VPN bağlantısını Ayarlar'daki VPN bölümünden açarsın.")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(18)
                    .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 22))
                }
                .padding()
            }
            .navigationTitle("Res VPN")
            .sheet(isPresented: $showShareSheet) {
                if let exportURL {
                    ActivityView(items: [exportURL])
                }
            }
            .alert("Profil oluşturulamadı", isPresented: Binding(
                get: { errorMessage != nil },
                set: { if !$0 { errorMessage = nil } }
            )) {
                Button("Tamam", role: .cancel) {}
            } message: {
                Text(errorMessage ?? "Bilinmeyen hata")
            }
            .onChange(of: server) { _, newValue in
                if remoteIdentifier.isEmpty {
                    remoteIdentifier = newValue
                }
            }
        }
    }

    private var statusCard: some View {
        VStack(spacing: 12) {
            Image(systemName: "lock.shield.fill")
                .font(.system(size: 42))
                .symbolRenderingMode(.hierarchical)

            Text("KİŞİSEL VPN")
                .font(.title2.bold())

            Text("0 TL • IKEv2 • iOS yerleşik VPN")
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 24)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 24))
    }

    private func field(
        _ title: String,
        text: Binding<String>,
        field: Field,
        keyboard: UIKeyboardType = .default,
        capitalization: TextInputAutocapitalization = .sentences
    ) -> some View {
        TextField(title, text: text)
            .keyboardType(keyboard)
            .textInputAutocapitalization(capitalization)
            .autocorrectionDisabled()
            .focused($focusedField, equals: field)
            .padding(14)
            .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 14))
    }

    private func createProfile() {
        focusedField = nil

        let profile = VPNProfile(
            displayName: displayName,
            server: server,
            remoteIdentifier: remoteIdentifier,
            username: username,
            password: password
        )

        do {
            let data = try MobileConfigBuilder.make(profile: profile)
            let safeFileName = displayName
                .replacingOccurrences(of: "/", with: "-")
                .replacingOccurrences(of: ":", with: "-")
                .trimmingCharacters(in: .whitespacesAndNewlines)

            let fileName = (safeFileName.isEmpty ? "ResVPN" : safeFileName) + ".mobileconfig"
            let url = FileManager.default.temporaryDirectory.appendingPathComponent(fileName)

            try data.write(to: url, options: .atomic)
            exportURL = url
            showShareSheet = true
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}
