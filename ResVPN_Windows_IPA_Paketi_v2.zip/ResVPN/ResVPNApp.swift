import SwiftUI

@main
struct ResVPNApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
