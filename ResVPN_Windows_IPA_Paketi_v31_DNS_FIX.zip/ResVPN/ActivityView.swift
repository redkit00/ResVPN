import SwiftUI
import UIKit

/// `.mobileconfig` dosyasını doğrudan Dosyalar'a kaydetmek için
/// iOS'un belge dışa aktarma ekranını kullanır.
/// Share sheet yerine bunu kullanıyoruz; iOS 26'da boş share sheet
/// görüntülenmesi sorununu önler.
struct ActivityView: UIViewControllerRepresentable {
    let items: [Any]

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let urls = items.compactMap { $0 as? URL }
        let picker = UIDocumentPickerViewController(forExporting: urls, asCopy: true)
        picker.shouldShowFileExtensions = true
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}
}
