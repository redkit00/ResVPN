import SwiftUI

struct ContentView: View {
    private let defaultServer = "78.174.76.233"
    private let remoteIdentifier = "78.174.76.233"
    private let username = "resvpn"

    @AppStorage("resvpnServer") private var server = "78.174.76.233"
    @State private var password = ""
    @State private var exportURL: URL?
    @State private var showShareSheet = false
    @State private var errorMessage: String?
    @State private var showAdvanced = false
    @FocusState private var passwordFocused: Bool

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 18) {
                    heroCard
                    countryCard
                    passwordCard
                    createButton
                    privacyCard
                    advancedCard
                }
                .padding()
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("Res VPN")
            .navigationBarTitleDisplayMode(.inline)
            .sheet(isPresented: $showShareSheet) {
                if let exportURL {
                    ActivityView(items: [exportURL])
                }
            }
            .alert("Profil oluşturulamadı", isPresented: Binding(
                get: { errorMessage != nil },
                set: { if !$0 { errorMessage = nil } }
            )) {
                Button("Tamam", role: .cancel) {}
            } message: {
                Text(errorMessage ?? "Bilinmeyen hata")
            }
        }
    }

    private var heroCard: some View {
        VStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(.blue.opacity(0.12))
                    .frame(width: 92, height: 92)

                Image(systemName: "shield.lefthalf.filled")
                    .font(.system(size: 46, weight: .semibold))
                    .foregroundStyle(.blue)
            }

            Text("Kişisel VPN")
                .font(.title2.bold())

            Text("Türkiye çıkışlı, kendi sunucun")
                .font(.subheadline)
                .foregroundStyle(.secondary)

            HStack(spacing: 8) {
                Image(systemName: "checkmark.seal.fill")
                    .foregroundStyle(.green)
                Text("Sunucu hazır")
                    .font(.subheadline.weight(.semibold))
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 8)
            .background(.green.opacity(0.10), in: Capsule())
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 24)
        .padding(.horizontal, 18)
        .background(.background, in: RoundedRectangle(cornerRadius: 26))
    }

    private var countryCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("SUNUCU")
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)

            HStack(spacing: 14) {
                Text("🇹🇷")
                    .font(.system(size: 34))

                VStack(alignment: .leading, spacing: 3) {
                    Text("Türkiye")
                        .font(.headline)
                    Text("Ev Sunucusu")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }

                Spacer()

                Image(systemName: "checkmark.circle.fill")
                    .font(.title2)
                    .foregroundStyle(.green)
            }

            Divider()

            HStack {
                Label("IKEv2", systemImage: "lock.fill")
                Spacer()
                Label("Şifreli DNS", systemImage: "network.badge.shield.half.filled")
            }
            .font(.footnote.weight(.medium))
            .foregroundStyle(.secondary)
        }
        .padding(18)
        .background(.background, in: RoundedRectangle(cornerRadius: 22))
    }

    private var passwordCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("VPN ŞİFRESİ")
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)

            SecureField("Sunucuda oluşturduğun VPN şifresi", text: $password)
                .textContentType(.password)
                .focused($passwordFocused)
                .padding(14)
                .background(Color(uiColor: .secondarySystemGroupedBackground),
                            in: RoundedRectangle(cornerRadius: 14))

            Text("Şifre uygulamanın ayarlarında saklanmaz. Profil oluşturulunca Dosyalar’a kaydetme ekranı açılır.")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .padding(18)
        .background(.background, in: RoundedRectangle(cornerRadius: 22))
    }

    private var createButton: some View {
        Button(action: createProfile) {
            HStack(spacing: 10) {
                Image(systemName: "arrow.down.doc.fill")
                Text("VPN Profilini Kaydet")
                    .fontWeight(.semibold)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 16)
        }
        .buttonStyle(.borderedProminent)
        .controlSize(.large)
        .disabled(password.isEmpty)
    }

    private var privacyCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("DNS koruması", systemImage: "lock.shield")
                .font(.headline)

            Text("VPN açıkken DNS sorguları tünelin içinden ev sunucusuna gider. Sunucu, DNS sorgularını dışarıya TLS ile şifreli olarak gönderir. Profili kaydettikten sonra Dosyalar uygulamasından .mobileconfig dosyasına dokunup iOS profilini kur.")
                .font(.subheadline)
                .foregroundStyle(.secondary)

            Text("Çıkış ülkesi: Türkiye")
                .font(.footnote.weight(.semibold))
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18)
        .background(.background, in: RoundedRectangle(cornerRadius: 22))
    }

    private var advancedCard: some View {
        DisclosureGroup("Gelişmiş", isExpanded: $showAdvanced) {
            VStack(alignment: .leading, spacing: 12) {
                Text("Public IP değişirse yalnızca aşağıdaki sunucu adresini güncelle.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)

                TextField("Sunucu IP / alan adı", text: $server)
                    .keyboardType(.URL)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .padding(12)
                    .background(Color(uiColor: .secondarySystemGroupedBackground),
                                in: RoundedRectangle(cornerRadius: 12))

                Button("Varsayılan IP'ye Dön") {
                    server = defaultServer
                }
                .font(.footnote)

                LabeledContent("Kullanıcı", value: username)
                    .font(.footnote)
                LabeledContent("Remote ID", value: remoteIdentifier)
                    .font(.footnote)
            }
            .padding(.top, 12)
        }
        .padding(18)
        .background(.background, in: RoundedRectangle(cornerRadius: 22))
    }

    private func createProfile() {
        passwordFocused = false

        let profile = VPNProfile(
            displayName: "Res VPN Türkiye",
            server: server,
            remoteIdentifier: remoteIdentifier,
            username: username,
            password: password
        )

        do {
            let data = try MobileConfigBuilder.make(profile: profile)
            let url = FileManager.default.temporaryDirectory
                .appendingPathComponent("ResVPN-Turkiye.mobileconfig")

            try data.write(to: url, options: .atomic)
            exportURL = url
            showShareSheet = true
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}
