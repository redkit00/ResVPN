# Res VPN v3.1 — iOS 26 boş ekran düzeltmesi

V3'te "VPN Profilini Hazırla" düğmesinden sonra bazı iOS 26 cihazlarda
paylaşım ekranı boş görünebiliyordu.

V3.1'de profil dışa aktarma yöntemi değiştirildi:

1. Uygulamayı aç.
2. VPN şifresini yaz.
3. `VPN Profilini Kaydet` düğmesine bas.
4. Açılan iOS `Dosyalar` ekranında `ResVPN-Turkiye.mobileconfig` dosyasını kaydet.
5. `Dosyalar` uygulamasını aç.
6. `ResVPN-Turkiye.mobileconfig` dosyasına dokun.
7. iPhone Ayarlar'a geç.
8. `Genel > VPN ve Aygıt Yönetimi` / `Profil İndirildi` bölümünden profili kur.
9. VPN'i Ayarlar > VPN bölümünden aç.

GitHub Actions:
- Bu ZIP'i eski v3 ZIP yerine repo'ya yükle.
- Workflow içindeki ZIP adını `ResVPN_Windows_IPA_Paketi_v31_DNS_FIX.zip` yap.
- Actions > Build > Run workflow.
- Oluşan unsigned IPA'yı Sideloadly ile yeniden kur.
