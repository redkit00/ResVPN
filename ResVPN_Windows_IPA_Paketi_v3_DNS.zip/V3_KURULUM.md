# Res VPN v3 — Türkiye + Şifreli DNS

## Uygulama
- Tek gerçek lokasyon: Türkiye.
- Sunucu: 78.174.76.233 (varsayılan).
- Kullanıcı: resvpn.
- Yalnızca VPN şifresini girersin.
- ResVPN Root CA profilde gömülüdür.
- IKEv2 tam tünel.
- Şifreli DNS desteği arayüzde gösterilir.

## Sunucuya şifreli DNS ekleme

Windows PowerShell:
scp .\SUNUCU_GUVENLI_DNS.sh resvpn@192.168.1.50:/home/resvpn/

SSH:
ssh resvpn@192.168.1.50

Ubuntu:
sudo bash /home/resvpn/SUNUCU_GUVENLI_DNS.sh

Script, 10.10.10.1 üzerinde Unbound kurar ve DNS sorgularını
Cloudflare/Quad9'a DNS-over-TLS ile gönderir. strongSwan istemcilere
10.10.10.1 DNS adresini dağıtır.

## IPA üretme
GitHub'da eski proje içeriğini bu v3 paketle değiştir.
.github/workflows/build-ipa.yml hazırdır.

Actions > Build ResVPN IPA > Run workflow

Artifact:
ResVPN-IPA > ResVPN-unsigned.ipa

Windows'ta Sideloadly ile iPhone'a imzala/kur.

## Önemli
Şu an sertifika Remote Identifier olarak 78.174.76.233 IP'sine bağlıdır.
Public IP değişirse sertifika/Remote ID güncellenmelidir. Sonraki adımda
ücretsiz DDNS alan adıyla bunu kalıcı hale getirebiliriz.
