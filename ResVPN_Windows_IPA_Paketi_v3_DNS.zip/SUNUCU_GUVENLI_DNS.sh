#!/usr/bin/env bash
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
  echo "Bu script root olarak çalışmalı: sudo bash SUNUCU_GUVENLI_DNS.sh"
  exit 1
fi

echo "[1/6] Paketler kuruluyor..."
apt update
apt install -y unbound ca-certificates iptables-persistent

echo "[2/6] VPN DNS IP'si kalıcı hale getiriliyor..."
cat >/etc/systemd/system/resvpn-dns-ip.service <<'EOF'
[Unit]
Description=ResVPN local DNS address
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/bin/sh -c '/sbin/ip addr show dev lo | grep -q "10.10.10.1/32" || /sbin/ip addr add 10.10.10.1/32 dev lo'
ExecStop=/bin/sh -c '/sbin/ip addr del 10.10.10.1/32 dev lo 2>/dev/null || true'

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now resvpn-dns-ip.service

echo "[3/6] Unbound şifreli DNS yapılandırılıyor..."
cat >/etc/unbound/unbound.conf.d/resvpn.conf <<'EOF'
server:
    interface: 10.10.10.1
    port: 53
    access-control: 10.10.10.0/24 allow
    access-control: 0.0.0.0/0 refuse

    do-ip4: yes
    do-ip6: no
    do-udp: yes
    do-tcp: yes

    hide-identity: yes
    hide-version: yes
    qname-minimisation: yes
    prefetch: yes
    harden-glue: yes
    harden-dnssec-stripped: yes

    tls-cert-bundle: "/etc/ssl/certs/ca-certificates.crt"

forward-zone:
    name: "."
    forward-tls-upstream: yes
    forward-addr: 1.1.1.1@853#cloudflare-dns.com
    forward-addr: 1.0.0.1@853#cloudflare-dns.com
    forward-addr: 9.9.9.9@853#dns.quad9.net
    forward-addr: 149.112.112.112@853#dns.quad9.net
EOF

unbound-checkconf
systemctl enable unbound
systemctl restart unbound

echo "[4/6] strongSwan istemcilere 10.10.10.1 DNS'i verecek şekilde ayarlanıyor..."
if grep -Eq '^[[:space:]]*rightdns=' /etc/ipsec.conf; then
  sed -i 's/^[[:space:]]*rightdns=.*/    rightdns=10.10.10.1/' /etc/ipsec.conf
else
  sed -i '/rightsourceip=/a\    rightdns=10.10.10.1' /etc/ipsec.conf
fi

systemctl restart strongswan-starter

echo "[5/6] IPv4 forwarding ve NAT kontrol ediliyor..."
cat >/etc/sysctl.d/99-resvpn.conf <<'EOF'
net.ipv4.ip_forward=1
EOF
sysctl --system >/dev/null

iptables -t nat -C POSTROUTING -s 10.10.10.0/24 -o enp0s3 -j MASQUERADE 2>/dev/null \
  || iptables -t nat -A POSTROUTING -s 10.10.10.0/24 -o enp0s3 -j MASQUERADE

iptables -C FORWARD -s 10.10.10.0/24 -j ACCEPT 2>/dev/null \
  || iptables -A FORWARD -s 10.10.10.0/24 -j ACCEPT

iptables -C FORWARD -d 10.10.10.0/24 -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT 2>/dev/null \
  || iptables -A FORWARD -d 10.10.10.0/24 -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT

netfilter-persistent save >/dev/null

echo "[6/6] Kontrol..."
echo
echo "DNS portu:"
ss -lunpt | grep '10.10.10.1:53' || true
echo
echo "strongSwan DNS ayarı:"
grep -E 'rightsourceip|rightdns' /etc/ipsec.conf || true
echo
echo "IKE portları:"
ss -lunp | grep -E ':(500|4500)' || true
echo
echo "TAMAM: ResVPN güvenli DNS aktif."
