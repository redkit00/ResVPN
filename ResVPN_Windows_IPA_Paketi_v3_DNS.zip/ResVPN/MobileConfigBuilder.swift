import Foundation

enum MobileConfigBuilderError: LocalizedError {
    case missingRequiredField

    var errorDescription: String? {
        switch self {
        case .missingRequiredField:
            return "Sunucu ve VPN şifresi zorunludur."
        }
    }
}

struct MobileConfigBuilder {
    private static let caCertificateBase64 = """
MIID9jCCAl6gAwIBAgIIEHHTzlhGfOEwDQYJKoZIhvcNAQELBQAwGTEXMBUGA1UEAxMOUmVzVlBOIFJvb3QgQ0EwHhcNMjYwOTA3MTMxNTE2WhcNMzYwOTA0MTMxNTE2WjAZMRcwFQYDVQQDEw5SZXNWUE4gUm9vdCBDQTCCAaIwDQYJKoZIhvcNAQEBBQADggGPADCCAYoCggGBAJLdaIoje3oZitMV2OVNBG7tPWfBK46OIGTt/lW56rjHTIoisPZU+M+zGV0OBuXlXRSdGydaNZt7F8yKBInZMkqAi9P+mL3Vo3bD50vH2gmLw25yDUg7MOCW7wPHrYVM4ErR31aHeLCksvmfap6BXKfZuchvKjPYEOhg2O0lYymDdwanevIuhvkPwM6wt5B2CfrUZX76/QpuhL/0AgDMpF+ABEZTXTnrBK0YdguzW8e3xqNFYPEf69wLuLipknvf5mFTxh7cZH6+Z1pEd41X2XJqOhyTeNwZfeScrllfZJ2slZ2Dao+C8mEAsnBykiagSiNNoriXCYliApwqDt93F8u0VzEeFsng6DPhrkBo3kkCCUhM4iDVXoSK7hggeVBR4Af6/HUTWAakEug4fYlnWxru4nL75ivnp3TGQFzgOKBpQsJ2VrAk9lIsIiJUdbjpjX9HO1iA8jl1YzxPY9mxZHgBqDMFOvHahbPn3QEXwRxdsoy4Cw6RAvWIQg1Rv+e/xwIDAQABo0IwQDAPBgNVHRMBAf8EBTADAQH/MA4GA1UdDwEB/wQEAwIBBjAdBgNVHQ4EFgQUhB0riZzPfNN0EWvxTRHWiZAeTucwDQYJKoZIhvcNAQELBQADggGBAI4pUaKltCCAYIrdDtds16s7eOGYnmc/tn4KtHAHWQHeLIsURObRh3quA9zwj3+my6Y3hSwSVDw5PTHAvy4d8vwKfeSYNZkC9y2EribvAY/iuwY8CaayzOvGQNSxQ9K2/C4Rc2hU3PNnrlWOdjlbuSng7oZAFK+k9ascJH33JfU9St4HGOdPgsUVRAeIrBNSu04AUpDsCUsc6xfzqD30xbeljixWDjeIwOToCxPkEnV692ENc15gJQu335G1g8tmkotPq5lGYJ7/Cznf4L5QAYh/LK13Oc4h4Fhu9oDNCIH2xGVTczsn2myome0xNK8JisQYuEO0ZRKeMKSgBcCSNm0NPKePtpEWrX/5CE1CJTLs6XcyDvpm0By8CV8yhW4EJoWFQTl4/kx7a1jywZIZ38KZu0CA5ySbpSKD7ORFGvGOiuKhTjJ9aqQBpjp1/4CvhhAZWbsBlCS6XQP2Phvw1N2Sgf/gPa6q7Y/x3yTygoyoixUwLGXWELehibB029LSFg==
"""

    static func make(profile: VPNProfile) throws -> Data {
        let displayName = profile.displayName.trimmingCharacters(in: .whitespacesAndNewlines)
        let server = profile.server.trimmingCharacters(in: .whitespacesAndNewlines)
        let remoteIdentifier = profile.remoteIdentifier.trimmingCharacters(in: .whitespacesAndNewlines)
        let username = profile.username.trimmingCharacters(in: .whitespacesAndNewlines)
        let password = profile.password

        guard !server.isEmpty,
              !remoteIdentifier.isEmpty,
              !username.isEmpty,
              !password.isEmpty else {
            throw MobileConfigBuilderError.missingRequiredField
        }

        let profileUUID = UUID().uuidString.uppercased()
        let caUUID = UUID().uuidString.uppercased()
        let vpnUUID = UUID().uuidString.uppercased()

        let safeName = xml(displayName.isEmpty ? "Res VPN Türkiye" : displayName)
        let safeServer = xml(server)
        let safeRemoteID = xml(remoteIdentifier)
        let safeUsername = xml(username)
        let safePassword = xml(password)

        let plist = """
        <?xml version="1.0" encoding="UTF-8"?>
        <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
        <plist version="1.0">
        <dict>
            <key>PayloadContent</key>
            <array>
                <dict>
                    <key>PayloadCertificateFileName</key>
                    <string>ResVPN-Root-CA.cer</string>
                    <key>PayloadContent</key>
                    <data>
                    \(caCertificateBase64)
                    </data>
                    <key>PayloadDescription</key>
                    <string>Res VPN sunucusunun kimliğini doğrulayan kök sertifika.</string>
                    <key>PayloadDisplayName</key>
                    <string>ResVPN Root CA</string>
                    <key>PayloadIdentifier</key>
                    <string>com.resvpn.profile.ca.\(caUUID)</string>
                    <key>PayloadOrganization</key>
                    <string>Res VPN</string>
                    <key>PayloadType</key>
                    <string>com.apple.security.root</string>
                    <key>PayloadUUID</key>
                    <string>\(caUUID)</string>
                    <key>PayloadVersion</key>
                    <integer>1</integer>
                </dict>

                <dict>
                    <key>PayloadDescription</key>
                    <string>Res VPN Türkiye IKEv2 bağlantısı</string>
                    <key>PayloadDisplayName</key>
                    <string>\(safeName)</string>
                    <key>PayloadIdentifier</key>
                    <string>com.resvpn.profile.vpn.\(vpnUUID)</string>
                    <key>PayloadType</key>
                    <string>com.apple.vpn.managed</string>
                    <key>PayloadUUID</key>
                    <string>\(vpnUUID)</string>
                    <key>PayloadVersion</key>
                    <integer>1</integer>

                    <key>UserDefinedName</key>
                    <string>\(safeName)</string>
                    <key>VPNType</key>
                    <string>IKEv2</string>

                    <key>IKEv2</key>
                    <dict>
                        <key>RemoteAddress</key>
                        <string>\(safeServer)</string>
                        <key>RemoteIdentifier</key>
                        <string>\(safeRemoteID)</string>

                        <key>AuthenticationMethod</key>
                        <string>None</string>
                        <key>ExtendedAuthEnabled</key>
                        <integer>1</integer>
                        <key>AuthName</key>
                        <string>\(safeUsername)</string>
                        <key>AuthPassword</key>
                        <string>\(safePassword)</string>

                        <key>ServerCertificateIssuerCommonName</key>
                        <string>ResVPN Root CA</string>

                        <key>DeadPeerDetectionRate</key>
                        <string>Medium</string>
                        <key>DisableMOBIKE</key>
                        <integer>0</integer>
                        <key>DisableRedirect</key>
                        <integer>0</integer>
                        <key>EnablePFS</key>
                        <integer>1</integer>
                    </dict>

                    <key>IPv4</key>
                    <dict>
                        <key>OverridePrimary</key>
                        <integer>1</integer>
                    </dict>

                    <key>Proxies</key>
                    <dict>
                        <key>HTTPEnable</key>
                        <integer>0</integer>
                        <key>HTTPSEnable</key>
                        <integer>0</integer>
                    </dict>
                </dict>
            </array>

            <key>PayloadDescription</key>
            <string>Res VPN Türkiye: IKEv2 VPN + güvenilir CA profili.</string>
            <key>PayloadDisplayName</key>
            <string>Res VPN Türkiye</string>
            <key>PayloadIdentifier</key>
            <string>com.resvpn.profile.\(profileUUID)</string>
            <key>PayloadOrganization</key>
            <string>Res VPN</string>
            <key>PayloadRemovalDisallowed</key>
            <false/>
            <key>PayloadScope</key>
            <string>User</string>
            <key>PayloadType</key>
            <string>Configuration</string>
            <key>PayloadUUID</key>
            <string>\(profileUUID)</string>
            <key>PayloadVersion</key>
            <integer>1</integer>
        </dict>
        </plist>
        """

        return Data(plist.utf8)
    }

    private static func xml(_ value: String) -> String {
        value
            .replacingOccurrences(of: "&", with: "&amp;")
            .replacingOccurrences(of: "<", with: "&lt;")
            .replacingOccurrences(of: ">", with: "&gt;")
            .replacingOccurrences(of: "\"", with: "&quot;")
            .replacingOccurrences(of: "'", with: "&apos;")
    }
}
